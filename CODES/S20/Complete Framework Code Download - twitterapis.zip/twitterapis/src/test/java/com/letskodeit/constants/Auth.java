package com.letskodeit.constants;

public class Auth {
	public static final String CONSUMER_KEY = "ubhe5nnmztzlJMzdLihtKEgsT";
	public static final String CONSUMER_SECRET = "KjDJDSJw2o882K71cK33PqUdRbIlp5DNxCxYknDrSvQwNsb2S1";
	public static final String ACCESS_TOKEN = "886092793365409792-mBtgcXzcn9IOC1WmWp5c1fXMn3HDZHr";
	public static final String ACCESS_SECRET = "jUIEOAnEiZLlICLBlpR6UhVKZ98CMpQ7banbfcP5gW3eS";
}