package com.letskodeit.constants;

public class Path {
	public static final String BASE_URI = "https://api.twitter.com";
	public static final String STATUSES = "/1.1/statuses";
}
